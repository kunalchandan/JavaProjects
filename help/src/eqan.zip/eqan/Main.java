package eqan;

public class Main {

	public static void main( String [] args){
		Window win = new Window();
		win.repaint();
	}
}
