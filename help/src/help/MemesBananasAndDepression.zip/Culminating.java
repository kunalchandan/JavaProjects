package help;

import javax.swing.*;

public class Culminating{

	public static void main( String [] args){
		Window win = new Window();
	}
}